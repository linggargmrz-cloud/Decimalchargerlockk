DECIMAL CHARGE LOCK v2.0
Build lokal: Android Studio (JDK 17) > Build > Build APK(s). Wrapper Gradle dibuat otomatis oleh Android Studio.
Build otomatis: unggah folder ke GitHub, tab Actions > Build APK > unduh artifact DecimalChargeLock.apk.
Setelah instal: buka aplikasi, tekan tombol 1-4, lalu atur izin MIUI (lihat layar aplikasi).
