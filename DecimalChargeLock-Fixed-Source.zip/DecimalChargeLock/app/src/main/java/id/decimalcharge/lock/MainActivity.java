package id.decimalcharge.lock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout box;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff000000);
        getWindow().setNavigationBarColor(0xff000000);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xff000000);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 64, 40, 40);
        sv.addView(box);
        setContentView(sv);

        label("Decimal Charge Lock", 0xffffffff, 24);
        label("\nLayar pengisian hitam penuh saat charger dicolokkan. Aktifkan layanan, lalu beri izin di bawah.", 0xffb8c4ca, 15);
        button("1. Aktifkan layanan", v -> startForegroundService(new Intent(this, ChargeService.class)));
        button("2. Izin notifikasi", v -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1));
        button("3. Izin tampil di atas aplikasi lain", v -> startActivity(new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))));
        button("4. Pengaturan aplikasi (MIUI)", v -> startActivity(new Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        label("\nDi MIUI: Izin lainnya > aktifkan \"Tampilkan di layar kunci\" dan \"Tampilkan jendela pop-up saat berjalan di latar belakang\". Di Keamanan > Izin > Autostart, aktifkan Decimal Charge Lock. Hemat baterai: pilih \"Tanpa pembatasan\".", 0xff8a979d, 13);
        label("\nCatatan: Android hanya melaporkan level baterai bulat. Desimal ditampilkan hanya bila bisa dihitung dari charge counter asli; jika tidak, yang tampil persentase bulat. Tekan lama layar pengisian untuk menutupnya.", 0xff8a979d, 13);
    }

    private void label(String t, int color, int sp) {
        TextView v = new TextView(this); v.setText(t); v.setTextColor(color); v.setTextSize(sp); box.addView(v);
    }

    private void button(String t, android.view.View.OnClickListener l) {
        Button bt = new Button(this); bt.setText(t); bt.setOnClickListener(l); box.addView(bt);
    }
}
