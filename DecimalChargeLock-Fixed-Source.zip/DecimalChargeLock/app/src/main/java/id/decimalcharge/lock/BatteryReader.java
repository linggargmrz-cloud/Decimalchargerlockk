package id.decimalcharge.lock;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Locale;

/** Membaca data baterai ASLI dari Android. Tidak ada angka desimal yang dikarang. */
final class BatteryReader {
    boolean charging;
    String text = "--";
    String note = "";

    static BatteryReader read(Context c) {
        BatteryReader r = new BatteryReader();
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return r;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        r.charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
        if (level < 0 || scale <= 0) return r;
        double base = 100.0 * level / scale;

        // Upaya desimal NYATA: charge counter (µAh) dibagi kapasitas penuh (µAh) dari sysfs.
        // Hanya dipakai jika kedua nilai terbaca dan konsisten dengan level bulat Android.
        Double real = null;
        try {
            BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
            long counter = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
            long full = readLong("/sys/class/power_supply/battery/charge_full");
            if (counter > 0 && full > 0) {
                double p = 100.0 * counter / full;
                if (p <= 100.0 && Math.abs(p - base) <= 1.0) real = p;
            }
        } catch (Throwable ignored) { }

        if (real != null) {
            r.text = String.format(new Locale("id", "ID"), "%.2f%%", real);
            r.note = "dihitung dari charge counter baterai";
        } else {
            r.text = String.format(new Locale("id", "ID"), "%.0f%%", base);
            r.note = "Android hanya melaporkan persentase bulat di HP ini";
        }
        return r;
    }

    private static long readLong(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            return Long.parseLong(br.readLine().trim());
        } catch (Throwable t) { return -1; }
    }
}
