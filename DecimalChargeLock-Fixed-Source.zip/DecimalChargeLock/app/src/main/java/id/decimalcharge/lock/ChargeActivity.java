package id.decimalcharge.lock;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChargeActivity extends Activity {
    private TextView clock, percent, status, note;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); handler.postDelayed(this, 1000); }
    };
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_POWER_DISCONNECTED.equals(i.getAction())) finish();
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK);

        clock = text(0xff9aa5ab, 26, false);
        percent = text(0xffffffff, 64, true);
        status = text(0xff7d8a91, 13, false);
        note = text(0xff4f5a60, 11, false);
        status.setPadding(0, 16, 0, 4);
        root.addView(clock); root.addView(percent); root.addView(status); root.addView(note);
        root.setOnLongClickListener(v -> { finish(); return true; });
        setContentView(root);
        hideSystemUi();
    }

    private TextView text(int color, int sp, boolean light) {
        TextView t = new TextView(this);
        t.setTextColor(color); t.setTextSize(sp); t.setGravity(Gravity.CENTER);
        if (light) t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        return t;
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void refresh() {
        BatteryReader r = BatteryReader.read(this);
        if (!r.charging) { finish(); return; }
        clock.setText(android.text.format.DateFormat.format("HH:mm", System.currentTimeMillis()));
        percent.setText(r.text);
        status.setText("SEDANG MENGISI DAYA");
        note.setText(r.note);
    }

    @Override protected void onStart() {
        super.onStart();
        registerReceiver(receiver, new IntentFilter(Intent.ACTION_POWER_DISCONNECTED));
        tick.run();
    }

    @Override protected void onStop() {
        handler.removeCallbacks(tick);
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        super.onStop();
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); hideSystemUi(); }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideSystemUi(); }
}
