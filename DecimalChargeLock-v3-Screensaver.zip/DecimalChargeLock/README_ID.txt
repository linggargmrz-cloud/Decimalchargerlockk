DECIMAL CHARGE LOCK v3 (screensaver / DreamService, tampilan jam + cincin + persen desimal + watt)
Build: unggah ke GitHub > Actions > Build APK > unduh DecimalChargeLock.apk, atau Android Studio (JDK 17) > Build APK(s).
Jika versi lama sudah terpasang, hapus dulu (tanda tangan debug berbeda).
